using UnityEngine;

public class Obstacle : MonoBehaviour
{
    public float obstacleHeightRange = 3f; // Height range for obstacles to appear at

    // Start is called before the first frame update
    void Start()
    {
        float randomHeight = Random.Range(-obstacleHeightRange, obstacleHeightRange);
        transform.position = new Vector3(transform.position.x, randomHeight, transform.position.z);
    }
}